import { StatusBar } from 'expo-status-bar';
import React from 'react'
import { StyleSheet, Button, View, SafeAreaView, Text, Image, Alert} from 'react-native';
import  { StackActions } from '@react-navigation/native';
export default function Jujutsu ({ navigation}) {
    return  (
     
        <View style={{flex: 1,backgroundColor: '#e6e6fa', justifyContent :'center',alignItems : 'center'}}>
         
       
         <Text style={styles.bigblack}>June 7, 2022 Chapter 1</Text>
         <View style={styles.screenContainer}>
         <Button
       height="100"
        title='Click Here'
        color="#4b0082"
        onPress = {()=> navigation.push('JJKChapter1 ')} />
      

      
      </View>
      <Text style={styles.bluelack}>June 1, 2022 Chapter 2</Text>
      <View style={styles.screenview}>
    
      <Button
       height="100"
        title='Click Here'
        color="#4b0082"
        onPress = {()=> navigation.push('JKChapter2')} />
       </View>
     
      <Text style={styles.greenlack}>June 7, 2022 Chapter 3</Text>
      <View style={styles.screenbase}>
      <Button
       height="100"
        title='Click Here'
        color="#4b0082"
        onPress = {()=> navigation.push('JKChapter3')} />
      
       </View>

       
       <Text style={styles.redlack}>June 14, 2022 Chapter 4</Text>
         <View style={styles.screenmode}>
         <Button
       height="100"
        title='Click Here'
        color="#4b0082"
        onPress = {()=> navigation.push('JKChapter4')} />
      

      
      </View>
      
      <Text style={styles.yellowlack}>June 22, 2022 Chapter 5</Text>
         <View style={styles.screenlinux}>
         <Button
       height="100"
        title='Click Here'
        color="#4b0082"
        onPress = {()=> navigation.push('JKChapter5')} />
      

      
      </View>
       
       </View>
)
}

const styles = StyleSheet.create({
  screenContainer: {
    position: 'absolute',
    right: 60,
    top: 60,
    flex: 1,
    justifyContent: "center",
    padding: 16
        
    },


    screenmode: {
      position: 'absolute',
    right: 60,
    top: 230,
    flex: 1,
    justifyContent: "center",
    padding: 16
          
      },
      screenlinux: {
        position: 'absolute',
      right: 60,
      top: 285,
      flex: 1,
      justifyContent: "center",
      padding: 16
            
        },


        screenview: {
          position: 'absolute',
        right: 60,
        top: 115,
        flex: 1,
        justifyContent: "center",
        padding: 16
              
          },


      screenbase: {
        position: 'absolute',
      right: 60,
      top: 170,
      flex: 1,
      justifyContent: "center",
      padding: 16
    },
    text:  {
        frontSize: 1,
        fontWeight: 'bold',
        margin: 100,
        textalign:"center"
    },
     
    bigblack: {
           
            position: 'absolute',
            right: 190,
            top: 80,
            fontWeight: 'bold',
            fontSize: 15,
            height:40,

        },
     
        bluelack: {
               
              
            position: 'absolute',
            right: 190,
            top: 135,
            fontWeight: 'bold',
            fontSize: 15,
            height:40,
                
        },



        greenlack: {
               
              
          position: 'absolute',
          right: 190,
          top: 193,
          fontWeight: 'bold',
          fontSize: 15,
          height:40,
              
      },

     redlack: {
           
        position: 'absolute',
        right: 190,
        top: 250,
        fontWeight: 'bold',
        fontSize: 15,
        height:40,

    },


    yellowlack: {
           
      position: 'absolute',
      right: 190,
      top: 305,
      fontWeight: 'bold',
      fontSize: 15,
      height:40,

  },

                submitButton: {
                  position: 'absolute',
                  bottom:200,
                  left:0,
              
                
    }
});