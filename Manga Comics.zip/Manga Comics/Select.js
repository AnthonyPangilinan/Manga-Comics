import { StatusBar } from 'expo-status-bar';
import React from 'react'
import { StyleSheet, Button, View, SafeAreaView, Text, Image, Alert} from 'react-native';
import  { StackActions } from '@react-navigation/native';
export default function Select ({ navigation}) {
    return  (
        <View style={{flex: 1,backgroundColor: '#FFC0CB', justifyContent :'center',alignItems : 'center'}}>
         
       
         <Image
          style={{ width: 200, height: 140 }}
          resizeMode="contain"
          source={{ uri: 'https://leosigh.com/wp-content/uploads/2022/03/Marin-dressed-as-Liz-kyun-in-My-Dress-Up-Darling-Episode-11-520x293.jpg' }}
        
        
        />  
        
         <Button
       height="100"
        title='My Dress up Darling'
        color="#ff1493"
        onPress = {()=> navigation.push('Dressup')} />
      
      
      <Image
          style={{ width: 200, height: 140 }}
          resizeMode="contain"
          source={{ uri: 'https://scontent.fmnl2-2.fna.fbcdn.net/v/t39.30808-6/277365283_687844629296936_8068462343754391752_n.jpg?_nc_cat=110&ccb=1-7&_nc_sid=e3f864&_nc_eui2=AeEVR9tXDodxm_Jb2thC7vK7tssbRIzQLkS2yxtEjNAuRJjt0ytNNOfcNXHIOafzdDwUoVnJh-Yu9wMBh6TeCggc&_nc_ohc=2ASzgEEuzZQAX_r19uI&_nc_ht=scontent.fmnl2-2.fna&oh=00_AT-Mn2bzTWk7G_1UyfShwNY5Pc6HUiFX6kfp38sgdHBcDA&oe=62A179F8' }}
        
        
        />  

      <Button
       height="50"
        title='Spy x Family'
        color="#dc143c"
        onPress = {()=> navigation.push('Spy')} />
      
      <Image
          style={{ width: 200, height: 140 }}
          resizeMode="contain"
          source={{ uri: 'https://www.dualshockers.com/static/uploads/2021/06/Jujutsu-Kaisen-Hiatus-Explained-When-Will-the-Manga-Return.jpg' }}
        
        
        />  
      <Button
       height="50"
        title='Jujutsu Kaisen'
        color="#4b0082"
        onPress = {()=> navigation.push('Jujutsu')} />
      
       
       
       </View>

    )
};

