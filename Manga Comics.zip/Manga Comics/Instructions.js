import { StatusBar } from 'expo-status-bar';
import React from 'react'
import { StyleSheet, Button, View, SafeAreaView, Text, Image, Alert} from 'react-native';
import  { StackActions } from '@react-navigation/native';
export default function Instructions ({ navigation}) {
return  (
        <View style={{flex: 1,backgroundColor: '#FFC0CB', justifyContent :'center',alignItems : 'center'}}>
         <Text style={styles.bigblack}>Instructions</Text>
         <Text style={styles.bluelack}>1.Read panels from right to left and in an up to down sequence. Like the pages of manga, individual panels should be read in a right to left sequence. Start reading each page by beginning with the panel that is in the upper right hand corner of the page. Read right to left and when you reach the edge of the page, go to the panel in the far-right of the following row of panels </Text>
         <Text style={styles.bluelack}>2.Read dialog balloons from right to left and up to down. Dialog balloons, which contain conversational text between characters, should also be read in a right to left sequence. Begin in the upper right hand corner of the individual panel and read the dialog balloons from right to left, and then up to down. </Text>
         <Text style={styles.bluelack}>3.Read black panel backgrounds as a flashback. When a manga panel has a background that is black, it is usually indicating that the events illustrated in the panel happened prior to the story being depicted in the manga. Black backgrounds signal a flashback to an earlier event or time period. </Text>



         <Button
       height="100"
        title='Next Screen'
        color="#ff1493"
        onPress = {()=> navigation.push('Select')} />
      
      
        </View>


)
}

const styles = StyleSheet.create({
    body: {
        flex: 1, 
        justifyContent: 'Center',
        clearImmediate
    },
    text:  {
        frontSize: 1000,
        fontWeight: 'bold',
        margin: 100,
        textalign:"center"
    },
     
    bigblack: {
            color: 'Black',
            fontWeight: 'bold',
            fontSize: 45,
            height:110,

        },
     
        bluelack: {
          
                
                fontWeight: 'bold',
                fontSize: 14,
                height:120,
                
                
    }
});