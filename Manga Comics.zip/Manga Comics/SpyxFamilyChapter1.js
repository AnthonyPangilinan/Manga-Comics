import React from 'react'
import { StyleSheet, ScrollView, Button, View, SafeAreaView, Text, Image, Alert} from 'react-native';

const   SpyxFamilyChapter2  = ({ navigation }) => {
    
    const logo = {
        uri: 'https://r-world.online/images/LOSn0Y3jaTa20fyrVxVU1626170303.jpg',
        width: 360,
        height: 550,
        right: 200,
        top: 1,
        flex: 1,
        justifyContent: "center",

        
        
      };

      const logs = {
        uri: 'https://r-world.online/images/gkuSaxIBoKiLcFOCeENp1626170303.jpg',
        width: 360,
        height: 550,
        right: 200,
        top: 1,
        flex: 1,
        justifyContent: "center",
         
      };

      const logi = {
        uri: 'https://r-world.online/images/nbh2bxrwbsBOX3JT2QTt1626170303.jpg',
        width: 360,
        height: 550,
        right: 200,
        top: 1,
        flex: 1,
        justifyContent: "center",
         
      };

      const loge = {
        uri: 'https://r-world.online/images/JhqufkSeimXHBsQKARij1626170303.jpg',
        width: 360,
        height: 550,
        right: 200,
        top: 1,
        flex: 1,
        justifyContent: "center",
         
      };


      const logm = {
        uri: 'https://r-world.online/images/rz3KWpgngyH0SFFeu1dQ1626170303.jpg',
        width: 360,
        height: 550,
        right: 200,
        top: 1,
        flex: 1,
        justifyContent: "center",
         
      };


      const lods = {
        uri: 'https://r-world.online/images/wXZ2nj8M79tff1BQMo1m1626170304.jpg',
        width: 360,
        height: 550,
        right: 200,
        top: 1,
        flex: 1,
        justifyContent: "center",
         
      };

      const lodg = {
        uri: 'https://r-world.online/images/Kocfzgvjcw5PLYZYKEVP1626170304.jpg',
        width: 360,
        height: 550,
        right: 200,
        top: 1,
        flex: 1,
        justifyContent: "center",
         
      };


      const lodf = {
        uri: 'https://r-world.online/images/EMIXNszOGjYoUGupLVAg1626170304.jpg',
        width: 360,
        height: 550,
        right: 200,
        top: 1,
        flex: 1,
        justifyContent: "center",
         
      };



      const lodk = {
        uri: 'https://r-world.online/images/nQE7MEmKlQZeWOCDbkkc1626170304.jpg',
        width: 360,
        height: 550,
        right: 200,
        top: 1,
        flex: 1,
        justifyContent: "center",
         
      };
      
    return  (

        
        <ScrollView>
    
        <Image source={logo} />
        
        <Image source={logi} />
        <Image source={loge} />
        <Image source={logm} />
        <Image source={lods} />
        <Image source={lodg} />
        <Image source={lodf} />
        <Image source={lodk} />

      </ScrollView>

           

    )
}

const styles = StyleSheet.create({
    screenContainer: {
      position: 'absolute',
      right: 60,
      top: 60,
      flex: 1,
      justifyContent: "center",
      padding: 16
          
      },
  
  
      screenmode: {
        position: 'absolute',
      right: 60,
      top: 230,
      flex: 1,
      justifyContent: "center",
      padding: 16
            
        },
        screenlinux: {
          position: 'absolute',
        right: 60,
        top: 285,
        flex: 1,
        justifyContent: "center",
        padding: 16
              
          },
  
  
          screenview: {
            position: 'absolute',
          right: 60,
          top: 115,
          flex: 1,
          justifyContent: "center",
          padding: 16
                
            },
  
  
        screenbase: {
          position: 'absolute',
        right: 60,
        top: 170,
        flex: 1,
        justifyContent: "center",
        padding: 16
      },
      text:  {
          frontSize: 1,
          fontWeight: 'bold',
          margin: 100,
          textalign:"center"
      },
       
      bigblack: {
             
              position: 'absolute',
              right: 50,
              top: 80,
              fontWeight: 'bold',
              fontSize: 50,
              height:100,
  
          },
       
          bluelack: {
                 
                
              position: 'absolute',
              right: 190,
              top: 135,
              fontWeight: 'bold',
              fontSize: 15,
              height:40,
                  
          },
  
  
  
          greenlack: {
                 
                
            position: 'absolute',
            right: 190,
            top: 193,
            fontWeight: 'bold',
            fontSize: 15,
            height:40,
                
        },
  
       redlack: {
             
          position: 'absolute',
          right: 190,
          top: 250,
          fontWeight: 'bold',
          fontSize: 15,
          height:40,
  
      },
  
  
      yellowlack: {
             
        position: 'absolute',
        right: 190,
        top: 305,
        fontWeight: 'bold',
        fontSize: 15,
        height:40,
  
    },
  
                  submitButton: {
                    position: 'absolute',
                    bottom:200,
                    left:0,
                
                
    }
});


          
    

export default   SpyxFamilyChapter2