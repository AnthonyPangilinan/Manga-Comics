import React from 'react'
import { StyleSheet, Button, View, SafeAreaView, Text, Image, Alert} from 'react-native';

const Home = ({ navigation }) => {
      return  (
        
       <View style={{flex: 5,backgroundColor: '#FFC0CB',  fontWeight: 'bold', justifyContent :'center',alignItems : 'center'}}>
            <Text style={styles.bigblack}>Manga Comics</Text>
       
       
       
          <Image
          style={{ width: 500, height: 200 }}
          resizeMode="contain"
          source={{ uri: 'https://leosigh.com/wp-content/uploads/2022/03/Marin-dressed-as-Liz-kyun-in-My-Dress-Up-Darling-Episode-11-520x293.jpg' }}
        
        
        />  
       
       <View style={{ height: 150, marginTop: 40 }}>
           <Button
           height="400"
        color="#ff1493"
        textalign="center"
        
         onPress = {()=> navigation.navigate('Menu')} title='Lets get Started'></Button>
     
     
        </View> 
 
        </View>

           

    )
}

const styles = StyleSheet.create({
    body: {
        flex: 1, 
        justifyContent: 'Center',
        clearImmediate
    },
    text:  {
        frontSize: 1000,
        fontWeight: 'bold',
        margin: 100,
        textalign:"center"
    },
     
    bigblack: {
          
            fontWeight: 'bold',
            fontSize: 45,
            height:110,
          
    }
});

export default Home