import { StatusBar } from 'expo-status-bar';
import React from 'react'
import { StyleSheet, Button, View, SafeAreaView, Text, Image, Alert} from 'react-native';
import  { StackActions } from '@react-navigation/native';
export default function Spy ({ navigation}) {
    return  (
     
        <View style={{flex: 1,backgroundColor: '#add8e6', justifyContent :'center',alignItems : 'center'}}>
         
       
         <Text style={styles.bigblack}>April 8, 2022 Chapter 1</Text>
         <View style={styles.screenContainer}>
         <Button
       height="100"
        title='Click Here'
        color="lightseagreen"
        onPress = {()=> navigation.push('SpyxFamilyChapter1')} />
      

      
      </View>
      <Text style={styles.bluelack}>April 17, 2022 Chapter 2</Text>
      <View style={styles.screenview}>
    
      <Button
       height="100"
        title='Click Here'
        color="lightseagreen"
        onPress = {()=> navigation.push('SpyxFamilyChapter2')} />
       </View>
     
      <Text style={styles.greenlack}>April 22, 2022 Chapter 3</Text>
      <View style={styles.screenbase}>
      <Button
       height="100"
        title='Click Here'
        color="lightseagreen"
        onPress = {()=> navigation.push('SpyxFamilyChapter3')} />
      
       </View>

       
       <Text style={styles.redlack}>April 29, 2022 Chapter 4</Text>
         <View style={styles.screenmode}>
         <Button
       height="100"
        title='Click Here'
        color="lightseagreen"
        onPress = {()=> navigation.push('SpyxFamilyChapter4')} />
      

      
      </View>
      
      <Text style={styles.yellowlack}>March 7, 2022 Chapter 5</Text>
         <View style={styles.screenlinux}>
         <Button
       height="100"
        title='Click Here'
        color="lightseagreen"
        onPress = {()=> navigation.push('SpyxFamilyChapter5')} />
      

      
      </View>
       
       </View>
)
}

const styles = StyleSheet.create({
  screenContainer: {
    position: 'absolute',
    right: 60,
    top: 60,
    flex: 1,
    justifyContent: "center",
    padding: 16
        
    },


    screenmode: {
      position: 'absolute',
    right: 60,
    top: 230,
    flex: 1,
    justifyContent: "center",
    padding: 16
          
      },
      screenlinux: {
        position: 'absolute',
      right: 60,
      top: 285,
      flex: 1,
      justifyContent: "center",
      padding: 16
            
        },


        screenview: {
          position: 'absolute',
        right: 60,
        top: 115,
        flex: 1,
        justifyContent: "center",
        padding: 16
              
          },


      screenbase: {
        position: 'absolute',
      right: 60,
      top: 170,
      flex: 1,
      justifyContent: "center",
      padding: 16
    },
    text:  {
        frontSize: 1,
        fontWeight: 'bold',
        margin: 100,
        textalign:"center"
    },
     
    bigblack: {
           
            position: 'absolute',
            right: 190,
            top: 80,
            fontWeight: 'bold',
            fontSize: 15,
            height:40,

        },
     
        bluelack: {
               
              
            position: 'absolute',
            right: 190,
            top: 135,
            fontWeight: 'bold',
            fontSize: 15,
            height:40,
                
        },



        greenlack: {
               
              
          position: 'absolute',
          right: 190,
          top: 193,
          fontWeight: 'bold',
          fontSize: 15,
          height:40,
              
      },

     redlack: {
           
        position: 'absolute',
        right: 190,
        top: 250,
        fontWeight: 'bold',
        fontSize: 15,
        height:40,

    },


    yellowlack: {
           
      position: 'absolute',
      right: 190,
      top: 305,
      fontWeight: 'bold',
      fontSize: 15,
      height:40,

  },

                submitButton: {
                  position: 'absolute',
                  bottom:200,
                  left:0,
              
                
    }
});