import React from 'react'
import { StyleSheet, ScrollView, Button, View, SafeAreaView, Text, Image, Alert} from 'react-native';

const JJKChapter1  = ({ navigation }) => {
    
    const logo = {
        uri: 'https://r-world.online/images/PxkeqckE5HUg8ZfCBPqk1611754548.jpg',
        width: 360,
        height: 550,
        right: 200,
        top: 1,
        flex: 1,
        justifyContent: "center",

        
        
      };

      const logs = {
        uri: 'https://r-world.online/images/zZ4xgIHPmYopWk6hB8Vo1611754548.jpg',
        width: 360,
        height: 550,
        right: 200,
        top: 1,
        flex: 1,
        justifyContent: "center",
         
      };

      const logi = {
        uri: 'https://r-world.online/images/WF8EAL4x13bB3EoHisC11611754549.jpg',
        width: 360,
        height: 550,
        right: 200,
        top: 1,
        flex: 1,
        justifyContent: "center",
         
      };

      const loge = {
        uri: 'https://r-world.online/images/OeusWQMquhdK41tUU7ri1611754550.jpg',
        width: 360,
        height: 550,
        right: 200,
        top: 1,
        flex: 1,
        justifyContent: "center",
         
      };


      const logm = {
        uri: 'https://r-world.online/images/OeusWQMquhdK41tUU7ri1611754550.jpg',
        width: 360,
        height: 550,
        right: 200,
        top: 1,
        flex: 1,
        justifyContent: "center",
         
      };


      const lods = {
        uri: 'https://r-world.online/images/5r2ibnknsBCUBlwmIvWt1611754550.jpg',
        width: 360,
        height: 550,
        right: 200,
        top: 1,
        flex: 1,
        justifyContent: "center",
         
      };

      const lodg = {
        uri: 'https://r-world.online/images/JSamlr44eu3p0AtAEyhh1611754550.jpg',
        width: 360,
        height: 550,
        right: 200,
        top: 1,
        flex: 1,
        justifyContent: "center",
         
      };


      const lodf = {
        uri: 'https://r-world.online/images/aQou3WWxFOPon4c9zlwB1611754551.jpg',
        width: 360,
        height: 550,
        right: 200,
        top: 1,
        flex: 1,
        justifyContent: "center",
         
      };



      const lodk = {
        uri: 'https://r-world.online/images/JFGyRBh9fWDJXByfjikk1611754551.jpg',
        width: 360,
        height: 550,
        right: 200,
        top: 1,
        flex: 1,
        justifyContent: "center",
         
      };
      
    return  (

        
        <ScrollView>
        
        <Image source={logo} />
        
        <Image source={logi} />
        <Image source={loge} />
        <Image source={logm} />
        <Image source={lods} />
        <Image source={lodg} />
        <Image source={lodf} />
        <Image source={lodk} />

      </ScrollView>

           

    )
}

const styles = StyleSheet.create({
    screenContainer: {
      position: 'absolute',
      right: 60,
      top: 60,
      flex: 1,
      justifyContent: "center",
      padding: 16
          
      },
  
  
      screenmode: {
        position: 'absolute',
      right: 60,
      top: 230,
      flex: 1,
      justifyContent: "center",
      padding: 16
            
        },
        screenlinux: {
          position: 'absolute',
        right: 60,
        top: 285,
        flex: 1,
        justifyContent: "center",
        padding: 16
              
          },
  
  
          screenview: {
            position: 'absolute',
          right: 60,
          top: 115,
          flex: 1,
          justifyContent: "center",
          padding: 16
                
            },
  
  
        screenbase: {
          position: 'absolute',
        right: 60,
        top: 170,
        flex: 1,
        justifyContent: "center",
        padding: 16
      },
      text:  {
          frontSize: 1,
          fontWeight: 'bold',
          margin: 100,
          textalign:"center"
      },
       
      bigblack: {
             
              position: 'absolute',
              right: 50,
              top: 80,
              fontWeight: 'bold',
              fontSize: 50,
              height:100,
  
          },
       
          bluelack: {
                 
                
              position: 'absolute',
              right: 190,
              top: 135,
              fontWeight: 'bold',
              fontSize: 15,
              height:40,
                  
          },
  
  
  
          greenlack: {
                 
                
            position: 'absolute',
            right: 190,
            top: 193,
            fontWeight: 'bold',
            fontSize: 15,
            height:40,
                
        },
  
       redlack: {
             
          position: 'absolute',
          right: 190,
          top: 250,
          fontWeight: 'bold',
          fontSize: 15,
          height:40,
  
      },
  
  
      yellowlack: {
             
        position: 'absolute',
        right: 190,
        top: 305,
        fontWeight: 'bold',
        fontSize: 15,
        height:40,
  
    },
  
                  submitButton: {
                    position: 'absolute',
                    bottom:200,
                    left:0,
                
                
    }
});


          
    

export default JJKChapter1